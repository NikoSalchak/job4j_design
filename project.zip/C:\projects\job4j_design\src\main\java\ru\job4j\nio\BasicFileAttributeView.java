package ru.job4j.nio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public class BasicFileAttributeView {
    public static void main(String[] args) throws IOException {
        Path file = Path.of("data/Attributes.txt");
        BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
        System.out.println("Это обычный файл? " + attrs.isRegularFile());
        System.out.println("Это директория? " + attrs.isDirectory());
        System.out.println("Это символическая ссылка? " + attrs.isSymbolicLink());
        System.out.println("Это не файл, директория или символическая ссылка? " + attrs.isOther());
        System.out.println("Дата создания файла: " + attrs.creationTime());
        System.out.println("Размер файла: " + attrs.size());
        System.out.println("Время последнего доступа: " + attrs.lastAccessTime());
        System.out.println("Время последнего изменения: " + attrs.lastModifiedTime());
        System.out.println(attrs.getClass());
    }
}

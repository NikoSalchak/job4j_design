package ru.job4j.nio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

public class PathAndFilesExample2 {
    public static void main(String[] args) throws IOException {
        Path filePath = Paths.get("file.txt");
        Path directoryPath = Paths.get("C:\\projects\\job4j_design\\tregulov\\M");
        Files.copy(filePath, directoryPath.resolve(filePath), StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Done!");
//        String dialog = "-Privet\n-Privet\n-Kak dela?\n-xorosho! kak y tebya";
//        Files.write(filePath, dialog.getBytes());
        List<String> list = Files.readAllLines(filePath);
        for (String s : list) {
            System.out.println(s);
        }
    }
}

package ru.job4j.workwithfiles;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriteEx {
    public static void main(String[] args) throws IOException {
        String string = "много лет размышлял я над жизнью земной. \n"
                + "Непонятного нет для меня под луной.\n"
                + "Мне известно, что мне ничего не известно.";
        FileWriter writer = null;
        try {
            writer = new FileWriter("tregulov/text1.txt");
            writer.write(string);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            writer.close();
        }
    }
}

package ru.job4j.set;

import java.util.Objects;

public class Dog {
    private String dog;
    private int age;

    public Dog(String dog, int age) {
        this.dog = dog;
        this.age = age;
    }

    public String getDog() {
        return dog;
    }

    public void setDog(String dog) {
        this.dog = dog;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{"
                + "dog='" + dog + '\''
                + ", age=" + age
                + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Dog dog1 = (Dog) o;
        return age == dog1.age && Objects.equals(dog, dog1.dog);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dog, age);
    }
}

package ru.job4j.generics;

public class Predator extends Animal {
    public Predator(String name, boolean sharpTeeth, float weight) {
        super(name, sharpTeeth, weight);
    }
}

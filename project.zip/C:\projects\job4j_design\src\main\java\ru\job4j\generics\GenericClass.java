package ru.job4j.generics;

public class GenericClass<K, V> {
    private K key;
    private V value;

    public GenericClass(K key, V value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public String toString() {
        return "GenericClass{"
                + "key=" + key
                + ", value=" + value
                + '}';
    }

    public static void main(String[] args) {
        GenericClass<String, String> first = new GenericClass<>("First key", "First value");
        System.out.println("Вывод в консоль: " + first);
        GenericClass<Integer, String> second = new GenericClass<>(12345, "Second value");
        System.out.println("Вывод в консоль: " + second);
    }
}

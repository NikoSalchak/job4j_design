package ru.job4j.iterator;

import java.util.*;

public class TestIterator {
    public static void split(List<ArrayList<Integer>> nodes, Iterator<Integer> source) {
        int index = 0;
        while (source.hasNext()) {
            if (index == nodes.size()) {
                index = 0;
            }
            ArrayList<Integer> data = nodes.get(index);
            int el = source.next();
            data.add(el);
            index++;
        }
        ArrayList<Integer> numbers = new ArrayList<>();
        Iterator<Integer> iterator = numbers.iterator();
        while (iterator.hasNext()) {
            if (iterator.next() == 30) {
                iterator.remove();
            }
        }
    }

    public static void main(String[] args) {
        int a = 42;
        int b = ~a;
        System.out.println(b);
    }
}

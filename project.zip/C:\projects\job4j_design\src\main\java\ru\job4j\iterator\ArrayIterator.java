package ru.job4j.iterator;
import java.util.*;

public class ArrayIterator implements Iterator<Integer> {
    private final int[] data;
    private int point;

    public ArrayIterator(int[] data) {
        this.data = data;
    }

    @Override
    public boolean hasNext() {
        return point < data.length;
    }

    @Override
    public Integer next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        return data[point++];
    }

    public static void main(String[] args) {
        ArrayIterator data = new ArrayIterator(
                new int[] {1}
        );
        System.out.println(data.hasNext());
        System.out.println(data.next());
        System.out.println(data.hasNext());
        LinkedList<Integer> list = new LinkedList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        System.out.println(list.get(3));
    }
}

package ru.job4j.io;

import java.io.IOException;

public class RandomAccessFile {
    public static void main(String[] args) {
        try (java.io.RandomAccessFile file =
                     new java.io.RandomAccessFile("tregulov/randomAccess.txt", "rw")) {
            int a = file.read();
            System.out.print((char) a);
            String a1 = file.readLine();
            System.out.println(a1);
            String a2 = file.readLine();
            System.out.println(a2);
            file.seek(101);
            String a3 = file.readLine();
            System.out.println(a3);
            long pos = file.getFilePointer();
            System.out.println(pos);
            file.seek(file.length() - 1);
            file.writeBytes("\nauthor");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package ru.job4j.workwithfiles;

import java.io.*;

public class CopyEx {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(
                new FileReader("C:\\Users\\Niko\\Desktop\\Temp\\photo_2023-09-17_07-39-26.jpg"));
             BufferedWriter writer = new BufferedWriter(
                     new FileWriter("tregulov/text2.txt"))
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.write('\n');
            }
            System.out.println("Done");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package ru.job4j.set;

import java.util.HashSet;
import java.util.Set;

public class DogsSet {
    public static void main(String[] args) {
        Dog jimmyOne = new Dog("fluffy", 3);
        Dog jimmyTwo = new Dog("fluffy", 3);
        Set<Dog> dogs = new HashSet<>();
        dogs.add(jimmyOne);
        dogs.add(jimmyTwo);
        System.out.println(dogs);
    }
}

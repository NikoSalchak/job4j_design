package ru.job4j.algorithms;

public class DeciBinaryNumber {
    public int minPartitioning(String n) {
        int length = n.length();
        char max = '0';
        for (int i = 0; i < length; i++) {
            char symbol = n.charAt(i);
            if (symbol > max) {
                max = symbol;
            }
        }
        return max - '0';
    }

    public static void main(String[] args) {
        String n = "567805";
        int result = new DeciBinaryNumber().minPartitioning(n);
        System.out.println(result);
    }
}

package ru.job4j.generics;

public class Tiger extends Predator {
    public Tiger(String name, boolean sharpTeeth, float weight) {
        super(name, sharpTeeth, weight);
    }
}
